#ifndef _FUNCONFIG_H
#define _FUNCONFIG_H

#define MINICHLINK         1

#endif

